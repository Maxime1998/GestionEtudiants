public class Parametres {
	static String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver"; // BESOIN POUR JDBC ET MYSQL
	static String url = "jdbc:postgresql://localhost:5432/postgres?zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimezone=UTC"; // CHANGER LE NOM DE LA BD JUSTE APRES LE 3EME SLASH
	static String usr = "postgres"; // CHANGER LE USER SI BESOIN
	static String pwd = "123456"; // CHANGER LE MDP SI BESOIN
}