
package com.arquitecturajava;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;

import com.etudiant.Bac;
import com.etudiant.Etudiant;
import com.etudiant.Semestre;

public class Outils {
	public static String lectureDeFichier(String f) throws FileNotFoundException {
		BufferedReader lecteur = null;
		FileReader fichier = new FileReader(f);
		String ligne;
		String result = "";
		try {
			lecteur = new BufferedReader(fichier);
			ligne = lecteur.readLine();
			while (ligne != null) {
				result += ligne + "\n";
				ligne = lecteur.readLine();

			}
			lecteur.close();
		} catch (Exception e) {

		}
		return result;
	}

	public static byte[] fichierEnArrayBytes(String locacion) throws IOException {
		File fichier = new File(locacion);
		byte[] fichierEnByte = new byte[(int) fichier.length()];
		InputStream stream = new FileInputStream(fichier);
		stream.read(fichierEnByte);
		return fichierEnByte;
	}

	public static ArrayList<String> genererLignesEtudiantsCSV(String location) {
		ArrayList<String> lignesEtudiants = new ArrayList<String>();
		String line;
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(location));
			line = br.readLine();
			while (line != null) {
				if (line != null && line.charAt(0) == '\"') {
					String s = lignesEtudiants.get(lignesEtudiants.size() - 1);
					lignesEtudiants.remove(lignesEtudiants.size() - 1);
					lignesEtudiants.add(s + line);
				} else if (line != null)
					lignesEtudiants.add(line);
				line = br.readLine();

			}
		} catch (IOException e) {
		}
		System.out.println(lignesEtudiants);
		lignesEtudiants.remove(0);
		return lignesEtudiants;
	}

	public static ArrayList<Etudiant> genererEtudiants(ArrayList<String> lignesEtudiants) {
		ArrayList<Etudiant> etudiants = new ArrayList<Etudiant>();
		for (String s : lignesEtudiants) {
			String[] champ = s.split(",");
			String[] date = champ[3].split("-");
			Calendar c = Calendar.getInstance();
			System.out.println("udfabufe---" + s);
			c.set(Integer.parseInt(date[2]) + 1900, Integer.parseInt(date[1]) - 1, Integer.parseInt(date[0]));
			String[] addresses = new String[2];
			addresses[0] = champ[5];
			addresses[1] = champ[6];
			Semestre[] sems = new Semestre[4];
			int j = 0;
			for (int i = 11; i < 23; i += 3) {
				sems[j] = new Semestre(champ[i + 1], champ[i + 2], Integer.parseInt(champ[i]));
				j++;
			}
			etudiants.add(new Etudiant(Integer.parseInt(champ[0]), champ[1], champ[2], champ[4], c,
					new Bac(champ[9], Integer.parseInt(champ[10])), champ[8], champ[7], sems, champ[24],
					Integer.parseInt(champ[23]), addresses, Integer.parseInt(champ[25])));
		}
		System.out.println(etudiants);
		return etudiants;
	}

	private static String returnResultatRequete(ResultSet rs) {
		String query = "";
		try {
			ResultSetMetaData rsmd = rs.getMetaData();
			int nbColonne = rsmd.getColumnCount();
			while (rs.next()) {
				for (int i = 1; i <= nbColonne; i++) {
					query += rs.getString(i) + "]";
				}
				query += "[";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (query.length() > 0)
			return query.substring(0, query.length() - 1);
		return "";

	}

	public static ArrayList<String> convertirRequeteEnFormatCSV(String requete) {
		ArrayList<String> aRet = new ArrayList<String>();
		String[] ligne = requete.split("\\[");
		for (int i = 0; i < ligne.length; i++) {
			String[] champ = ligne[i].split("]");
			String ligneCorrecte = "";
			for (int j = 0; j < champ.length; j++) {
				ligneCorrecte += champ[j] + ",";
			}
			ligneCorrecte.substring(0, ligneCorrecte.length() - 1);
			ligneCorrecte += '\n';
			aRet.add(ligneCorrecte);
		}
		return aRet;
	}

	public static Resource chargerRessource(String filename) throws Exception {
		Resource resource = new ByteArrayResource(Outils.fichierEnArrayBytes(filename));
		return resource;
	}

	public static int uploadArrayEtudiants(ArrayList<Etudiant> listeEtudiants) {
		SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
		for (Etudiant e : listeEtudiants) {
			try {
				performSQL("insert into etudiant values(" + e.getIdEtud() + ",'" + e.getNom() + "','" + e.getPrenom()
						+ "','" + s.format(e.getDateNaissance().getTime()) + "','" + e.getSexe() + "','"
						+ e.getAdresse()[0] + "','" + e.getAdresse()[1] + "','" + e.getTelephone() + "','" + e.getMail()
						+ "','" + e.getBac().getType() + "'," + e.getBac().getAnneeBac() + ","
						+ e.getSemestres()[0].getNote() + ",'" + e.getSemestres()[0].getResultat() + "','"
						+ e.getSemestres()[0].getCommentaire() + "'," + e.getSemestres()[1].getNote() + ",'"
						+ e.getSemestres()[1].getResultat() + "','" + e.getSemestres()[1].getCommentaire() + "',"
						+ e.getSemestres()[2].getNote() + ",'" + e.getSemestres()[2].getResultat() + "','"
						+ e.getSemestres()[2].getCommentaire() + "'," + e.getSemestres()[3].getNote() + ",'"
						+ e.getSemestres()[3].getResultat() + "','" + e.getSemestres()[3].getCommentaire() + "',"
						+ e.getNbAnneesDUT() + ",'" + e.getPoursuite() + "'," + e.getPromo() + ")");
			} catch (SQLException exc) {
				exc.printStackTrace();
				return -1;
			}
		}
		return 0;
	}

	public static String requeteSQL(String requete) throws SQLException {
		Connection co;
		co = DriverManager.getConnection(Parametres.url, Parametres.usr, Parametres.pwd);
		Statement st = co.createStatement();
		ResultSet rs = st.executeQuery(requete);
		return Outils.returnResultatRequete(rs);
	}

	public static void performSQL(String requete) throws SQLException {
		Connection co;
		co = DriverManager.getConnection(Parametres.url, Parametres.usr, Parametres.pwd);
		Statement st = co.createStatement();
		st.execute(requete);
	}

}
