package com.arquitecturajava;

public class Test {
	public static String essai() {
		return "<html>"
				+ "<head>"
				+ "	<LINK href=\"special.css\" rel=\"stylesheet\" type=\"text/css\">"
				+ "</head>"
				+ "<body>"
				+ "<p>Bonjour</p>"
				+ "</body>"
				+ "</html>";
	}
}
