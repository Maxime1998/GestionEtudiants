package com.arquitecturajava;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.etudiant.Etudiant;
import com.etudiant.test;


@Controller
public class ControladorHola {

	private ArrayList<Etudiant> etudiants =null;

	/** Lit feuille CSV, fait charger une feuille de style CSS 
	 * @throws FileNotFoundException 
	 * @throws SQLException **/
	@RequestMapping("/")
	@ResponseBody
	String home() throws FileNotFoundException, SQLException {
		String requete = Outils.requeteSQL("select * from etudiant");
		System.out.println(requete);
		ArrayList<String> lignesEt = Outils.convertirRequeteEnFormatCSV(requete);
		this.etudiants = Outils.genererEtudiants(lignesEt);
		 return Outils.lectureDeFichier("header1.html")+test.tableau(etudiants)+Outils.lectureDeFichier("exportation.html")+Outils.lectureDeFichier("footer.html");
	}

	 @RequestMapping("/modif")
	 @ResponseBody
	 String modif(HttpServletRequest requete) throws FileNotFoundException{
		
		String d =requete.getParameter("id");
		
		 return Outils.lectureDeFichier("header.html")+test.modifEtudiant(d,this.etudiants)+Outils.lectureDeFichier("footer.html");
		 
		 
	 }
	 

	 @RequestMapping("ajout")
	 @ResponseBody
	 String ajout(HttpServletRequest requete) throws FileNotFoundException{
		 String resultat = test.testChamp(requete);
		 
		 return Outils.lectureDeFichier("header1.html")+resultat+Outils.lectureDeFichier("ajout.html")+Outils.lectureDeFichier("footer.html");
		 
		 
	 }
	 
	 
	 
	/** Envoi de feuille de style **/
	@RequestMapping("/special.css")
	@ResponseBody
	String special() throws FileNotFoundException {
		return Outils.lectureDeFichier("special.css");
	}

	/** Formulaire POST/GET simples **/
	@RequestMapping("/testPOST")
	@ResponseBody
	String testPOST(HttpServletRequest requete) throws FileNotFoundException {
		return Outils.lectureDeFichier("Formulaire.html") + requete.getParameter("value1") + "---"
				+ requete.getParameter("value2");
	}

	/** Envoi et stockage de fichier uploadé **/
	// Formulaire de upload
	@RequestMapping("/testFormFichier")
	@ResponseBody
	String testFormFichier(HttpServletRequest requete) throws FileNotFoundException {
		return Outils.lectureDeFichier("Fichier.html") + requete.getParameter("nomFichier");
	}

	// Traitement et redirection
	@RequestMapping("/testFichier")
	@ResponseBody
	String testFichier(HttpServletResponse reponse, @RequestParam("nom") MultipartFile file)
			throws IllegalStateException, IOException {
		// String[] extension = file.getOriginalFilename().split(".");
		if (!file.getOriginalFilename().equals("")/** &&extension[extension.length-1].equals("csv") **/
		) {
			File fichierDest = new File("C:/Users/ezech/Desktop" + "aTraiter.csv");
			file.transferTo(fichierDest);
			ArrayList<String> listeLignes = Outils.genererLignesEtudiantsCSV("aTraiter.csv");
			ArrayList<Etudiant> liste = Outils.genererEtudiants(listeLignes);
			Outils.uploadArrayEtudiants(liste);
			reponse.sendRedirect("importation.html");
		} else
			reponse.sendRedirect("importation.html");
		return "NULL";
	}

	/** Envoi de feuille de style **/

	@RequestMapping("/style.css")
	@ResponseBody
	String style() throws FileNotFoundException {
		return Outils.lectureDeFichier("style.css");
	}

	@RequestMapping("/importation.html")
	@ResponseBody
	String importation() throws FileNotFoundException {
		return Outils.lectureDeFichier("header.html") + Outils.lectureDeFichier("importation.html")
				+ Outils.lectureDeFichier("footer.html");
	}

	@RequestMapping("/test.jpg")
	public ResponseEntity<Resource> serveFile() throws Exception {
		Resource file = Outils.chargerRessource("/home/vincent/Téléchargements/HolaSpringBoot/rod-fanni.jpg");
		return ResponseEntity.ok().header("filename=\"test.jpg" + "\"")
				.body(file);
	}

	@RequestMapping("/testRequete")
	@ResponseBody
	String testSQL() throws SQLException {
		String requete = Outils.requeteSQL("select * from etudiant");
		System.out.println(requete);
		ArrayList<String> lignesEt = Outils.convertirRequeteEnFormatCSV(requete);
		ArrayList<Etudiant> etudiants = Outils.genererEtudiants(lignesEt);
		return etudiants.toString();
	}
}