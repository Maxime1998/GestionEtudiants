package com.etudiant;

public class Semestre {
	private Integer note;
	private String resultat;
	private String commentaire;
	
	public Semestre(String resultat, String commentaire, int note) {
		this.setNote(note);
		this.setResultat(resultat);
		this.setCommentaire(commentaire);
	}
	
	public Semestre(String resultat, String commentaire, String note) {
		if (note==null || note.equals("")) {
			this.note = null;
		}else{
			this.note =Integer.parseInt(note);
		}

		
		this.setResultat(resultat);
		this.setCommentaire(commentaire);
	}

	public Integer getNote() {
		return note;
	}

	public void setNote(int note) {
		this.note = note;
	}

	public String getResultat() {
		return resultat;
	}

	public void setResultat(String resultat) {
		this.resultat = resultat;
	}

	public String getCommentaire() {
		return commentaire;
	}

	public void setCommentaire(String commentaire) {
		this.commentaire = commentaire;
	}
}
