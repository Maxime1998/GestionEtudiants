package com.etudiant;

public class Semestre1 {
	private int note;
	private String resultat;
	private String commentaire;
	
	public Semestre1(String resultat, String commentaire, int note) {
		this.setNote(note);
		this.setResultat(resultat);
		this.setCommentaire(commentaire);
	}

	public int getNote() {
		return note;
	}

	public void setNote(int note) {
		this.note = note;
	}

	public String getResultat() {
		return resultat;
	}

	public void setResultat(String resultat) {
		this.resultat = resultat;
	}

	public String getCommentaire() {
		return commentaire;
	}

	public void setCommentaire(String commentaire) {
		this.commentaire = commentaire;
	}
}
