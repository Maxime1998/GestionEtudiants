package com.etudiant;
public class Poursuite1 {
	private String intitule;
	private boolean enAlternance;
	
	public Poursuite1(String intitule, boolean alt) {
		this.intitule = intitule;
		this.enAlternance = alt;
	}

	public String getIntitule() {
		return intitule;
	}

	public boolean isEnAlternance() {
		return enAlternance;
	}
	
	
}
