package com.etudiant;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;


public class Lecture {

	public static void main(String[] args) throws FileNotFoundException{
		System.out.println(lectureDeFichier("src/text.txt"));
		
	
	
		
	}
	
	
	static String lectureDeFichier(String f) throws FileNotFoundException {
		
		BufferedReader lecteur = null;
		FileReader fichier = new FileReader(f);
		String ligne;
		String result ="";
	
		try {
			lecteur = new BufferedReader(fichier);
			ligne=lecteur.readLine();
			while (ligne!=null) {
				result +=ligne+"\n";
				ligne =lecteur.readLine();
				
			}
	
			lecteur.close();	
		} catch (Exception e) {
			
		}
	
		
		return result;
		
	}

}
