package com.etudiant;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Etudiant {
	private int idEtud;
	private String nom;
	private String prenom;
	private String sexe;
	private Calendar dateNaissance;
	private Bac bac;
	private Semestre[] semestres;
	private String mail;
	private String telephone;
	private String poursuite;
	private String[] adresse;
	private int nbAnneesDUT;
	private int promo;
	
	
	public Etudiant(int idEtud, String nom, String prenom, String sexe, Calendar dateNaissance, Bac bac, String mail, String tel, Semestre[] semestres, String poursuites, int nbAnneesDut, String[] adresse, int promo) {
		this.idEtud = idEtud;
		this.nom = nom;
		this.prenom = prenom;
		this.sexe = sexe;
		this.bac = bac;
		this.dateNaissance = dateNaissance;
		this.semestres = semestres;
		this.poursuite = poursuites;
		this.mail = mail;
		this.telephone = tel;
		this.nbAnneesDUT = nbAnneesDut;
		this.adresse = adresse;
		this.setPromo(promo);
	}
	
	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public String getSexe() {
		return sexe;
	}

	public Calendar getDateNaissance() {
		return dateNaissance;
	}

	public Bac getBac() {
		return bac;
	}
	
	public Semestre[] getSemestres() {
		return semestres;
	}
	public int getIdEtud() {
		return idEtud;
	}
	public String getMail() {
		return mail;
	}

	public String getTelephone() {
		return telephone;
	}

	public String getPoursuite() {
		return poursuite;
	}

	@Override
	public String toString() {
		SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
		
		return "Etudiant [nom=" + nom + ", prenom=" + prenom + ", sexe=" + sexe + ", dateNaissance=" + s.format(dateNaissance.getTime())
				+ ", bac=" + bac + "]\n<br />";
	}

	public int getNbAnneesDUT() {
		return nbAnneesDUT;
	}

	public void setNbAnneesDUT(int nbAnneesDUT) {
		this.nbAnneesDUT = nbAnneesDUT;
	}

	public String[] getAdresse() {
		return adresse;
	}

	public void setAdresse(String[] adresse) {
		this.adresse = adresse;
	}

	public int getPromo() {
		return promo;
	}

	public void setPromo(int promo) {
		this.promo = promo;
	}
}
