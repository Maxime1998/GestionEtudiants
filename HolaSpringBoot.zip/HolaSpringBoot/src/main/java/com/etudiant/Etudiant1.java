package com.etudiant;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Etudiant1 {
	private int idEtud;
	private String nom;
	private String prenom;
	private String sexe;
	private Calendar dateNaissance;
	private Bac1 bac;
	private String[] semestres;
	private String mail;
	private String telephone;
	private Poursuite1[] poursuite;
	
	
	public Etudiant1(int idEtud, String nom, String prenom, String sexe, Calendar dateNaissance, Bac1 bac, String mail, String tel, String[] semestres, Poursuite1[] poursuites) {
		this.idEtud = idEtud;
		this.nom = nom;
		this.prenom = prenom;
		this.sexe = sexe;
		this.bac = bac;
		this.dateNaissance = dateNaissance;
		this.semestres = new String[4];
		this.poursuite = new Poursuite1[3];
		this.mail = mail;
		this.telephone = tel;
	}
	
	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public String getSexe() {
		return sexe;
	}

	public Calendar getDateNaissance() {
		return dateNaissance;
	}

	public Bac1 getBac() {
		return bac;
	}
	
	public String[] getSemestres() {
		return semestres;
	}
	public int getIdEtud() {
		return idEtud;
	}
	public String getMail() {
		return mail;
	}

	public String getTelephone() {
		return telephone;
	}

	public Poursuite1[] getPoursuite() {
		return poursuite;
	}

	@Override
	public String toString() {
		SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
		
		return "Etudiant [nom=" + nom + ", prenom=" + prenom + ", sexe=" + sexe + ", dateNaissance=" + s.format(dateNaissance.getTime())
				+ ", bac=" + bac + "]\n<br />";
	}
}
