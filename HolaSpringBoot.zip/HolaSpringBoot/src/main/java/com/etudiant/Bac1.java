package com.etudiant;

public class Bac1 {
	private String type;
	private String mention;
	private int anneeBac;
	
	public Bac1(String type, String mention, int anneeBac) {
		this.type = type;
		this.mention = mention;
		this.anneeBac = anneeBac;
	}

	public String getType() {
		return type;
	}

	public String getMention() {
		return mention;
	}

	public int getAnneeBac() {
		return anneeBac;
	}
	
	
}
