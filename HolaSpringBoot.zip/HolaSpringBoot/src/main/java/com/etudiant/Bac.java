package com.etudiant;

public class Bac {
	private String type;
	private Integer anneeBac;
	
	public Bac(String type, int anneeBac) {
		this.type = type;
		this.anneeBac = anneeBac;
	}
	public Bac(String type, String anneeBac) {
		this.type = type;
		
		if (anneeBac==null || anneeBac.equals("")) {
			this.anneeBac=null;
		}else{
			this.anneeBac = Integer.parseInt(anneeBac);
		}
		

	}
	public String getType() {
		return type;
	}

	public Integer getAnneeBac() {
		return anneeBac;
	}
	
	
}
