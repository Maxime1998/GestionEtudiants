package com.etudiant;
import java.util.ArrayList;

public class Statistique {
/*
	private ArrayList<Etudiant> listeEtudiants;
	
	
	public Statistique(ArrayList<Etudiant> lEtud) {
		this.listeEtudiants= lEtud;
	}
	
	*/
	
	public static String CalculStatistique(ArrayList<Etudiant1> lEtud,ArrayList<String> choix) {
		String res ="";
		for (String s : choix) {
			switch (s) {
			case "bac":
				res +=statBac(lEtud);
				break;
			case "sexe":
				res +=statSexe(lEtud);
				break;
			default:
				break;
			}
		}
		
		return res;

		
	}
	
	
	
	private static String statSexe(ArrayList<Etudiant1> le) {
		
		int fille =0;
		int garcon =0;
		
		for (Etudiant1 e : le) {
			if (e.getSexe().equals("F")) {
				fille++;
			}else {
				garcon++;
			}
		}
		
		
		return ((fille*100)/le.size()) +" % des �tudiants sont des filles \n"+((garcon*100)/le.size()) +" % des �tudiants sont des garcons \n";
		
	}
	
	
	
	
	private static String statBac(ArrayList<Etudiant1> le) {
		String result="";
		ArrayList<String> typeBac = new ArrayList<>();
		
		for (Etudiant1 e : le) {
			if (!typeBac.contains(e.getBac().getType())) {
				typeBac.add(e.getBac().getType());
			}
		}
		
		for (String s : typeBac) {
			int nbEtudTypeBac= 0;
			
			for (Etudiant1 e : le) {
				if (e.getBac().getType().equals(s)) {
					nbEtudTypeBac++;
				}
			}
			
			result+=((nbEtudTypeBac*100)/le.size()) +" % des �tudiants ont un "+s+"\n";
		}
		
		
		return result;
		
		
		
	}
	
	
	
	
	
	
}
