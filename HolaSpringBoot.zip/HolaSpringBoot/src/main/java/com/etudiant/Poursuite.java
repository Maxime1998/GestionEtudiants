package com.etudiant;

public class Poursuite {
	private String intitule;
	private boolean enAlternance;
	
	public Poursuite(String intitule, boolean alt) {
		this.intitule = intitule;
		this.enAlternance = alt;
	}

	public String getIntitule() {
		return intitule;
	}

	public boolean isEnAlternance() {
		return enAlternance;
	}
	
}
