package com.etudiant;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;

import com.arquitecturajava.Outils;

public class test {
	
	
	
	private static String pageHaut() {
		
		
		return 	"	<div class=\"limiter\">\r\n" + 
				"			<div class=\"wrap-table100\">\r\n" + 
				"				<div class=\"table100 ver1 m-b-110\">\r\n" + 
				"					<table data-vertable=\"ver1\">\r\n" + 
				"						<thead>\r\n" + 
				"							<tr class=\"row100 head\">\r\n" + 
				"								<th class=\"column100 column1\" >Nom</th>\r\n" + 
				"								<th class=\"column100 column2\" >Prenom</th>\r\n" + 
				"								<th class=\"column100 column3\" >Date de Naissance</th>\r\n" + 
				"								<th class=\"column100 column4\" >Sexe</th>\r\n" + 
				"								<th class=\"column100 column6\" >Adr1</th>\r\n" + 
				"								<th class=\"column100 column7\" >Adr2</th>\r\n" + 
				"								<th class=\"column100 column8\" >Telephone</th>\r\n" + 
				"								<th class=\"column100 column1\" >Email</th>\r\n" + 
				"								<th class=\"column100 column2\" >Type Bac</th>\r\n" + 
				"								<th class=\"column100 column3\" >Annee Bac</th>\r\n" + 
				"								<th class=\"column100 column4\" >Note S1</th>\r\n" + 
				"								<th class=\"column100 column5\" >Resultat S1</th>\r\n" + 
				"								<th class=\"column100 column6\" >Commentaire</th>\r\n" + 
				"								<th class=\"column100 column4\" >Note S2</th>\r\n" + 
				"								<th class=\"column100 column5\" >Resultat S2</th>\r\n" + 
				"								<th class=\"column100 column6\" >Commentaire</th>\r\n" + 
				"								<th class=\"column100 column4\" >Note S3</th>\r\n" + 
				"								<th class=\"column100 column5\" >Resultat S3</th>\r\n" + 
				"								<th class=\"column100 column6\" >Commentaire</th>\r\n" + 
				"								<th class=\"column100 column4\" >Note S4</th>\r\n" + 
				"								<th class=\"column100 column5\" >Resultat S4</th>\r\n" + 
				"								<th class=\"column100 column6\" >Commentaire</th>\r\n" + 
				"								<th class=\"column100 column5\" >DUT 2 ou 3</th>\r\n" + 
				"								<th class=\"column100 column6\" >Apres DUT</th>\r\n" + 
				"								<th class=\"column100 column5\" >Promo</th>\r\n" + 
				"								<th class=\"column100 column6\" >Commentaire</th>\r\n" + 
				"\r\n" + 
				"							</tr>\r\n" + 
				"						</thead>\r\n" + 
				"						<tbody>";
	}
	
	private static String pageBas() {
		
		
		return " \r\n" + 
				"						</tbody>\r\n" + 
				"					</table>\r\n" + 
				"			</div>\r\n" + 
				"		</div>\r\n" + 
				"	</div>\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"<!--===============================================================================================-->	\r\n" + 
				"	<script src=\"vendor/jquery/jquery-3.2.1.min.js\"></script>\r\n" + 
				"<!--===============================================================================================-->\r\n" + 
				"	<script src=\"vendor/bootstrap/js/popper.js\"></script>\r\n" + 
				"	<script src=\"vendor/bootstrap/js/bootstrap.min.js\"></script>\r\n" + 
				"<!--===============================================================================================-->\r\n" + 
				"	<script src=\"vendor/select2/select2.min.js\"></script>\r\n" + 
				"<!--===============================================================================================-->\r\n" + 
				"	<script src=\"js/main.js\"></script>\r\n" + 
				"\r\n";
	} 
	
	
	
	public static String tableau(ArrayList<Etudiant> listeE) {
		int ligne = listeE.size();
		System.out.println("TAILLLLLE"+listeE.size());
		String Hp=pageHaut();
		
		for (int i = 0; i < ligne; i++) {
			SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
			
			String tel=listeE.get(i).getTelephone();
			
			if (tel.charAt(0)=='$') {
				tel= tel.substring(1);
			}
			
			
			
				Hp+="<tr class=\"row100\">\r\n" +
						"<td class=\"column100 column1\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getNom()+"</td>"+" \r\n" + 
						"<td class=\"column100 column2\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getPrenom()  +"</td>\r\n" + 
						"<td class=\"column100 column3\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ s.format(listeE.get(i).getDateNaissance().getTime())+"</td>\r\n" + 
						"<td class=\"column100 column4\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSexe() +"</td>\r\n" + 
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getAdresse()[0]+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getAdresse()[1]+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ tel+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getMail()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getBac().getType()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getBac().getAnneeBac()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[0].getNote()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[0].getResultat()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[0].getCommentaire()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[1].getNote()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[1].getResultat()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[1].getCommentaire()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[2].getNote()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[2].getResultat()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[2].getCommentaire()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[3].getNote()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[3].getResultat()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getSemestres()[3].getCommentaire()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getNbAnneesDUT()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getPoursuite()+"</td>"+
						"<td class=\"column100 column5\" ><a href="+"modif"+"?id="+listeE.get(i).getIdEtud()+">"+ listeE.get(i).getPromo()+"</td>";
						
				
			}
		
		
		
		Hp+=pageBas();
		
		
		
		return Hp;
	}
	
	
	
	public static String modifEtudiant(String ID,ArrayList<Etudiant> listeE) {
		
		int id = Integer.parseInt(ID);
		Etudiant et = null;
		for (Etudiant e : listeE) {
			if (e.getIdEtud()==id) {
				et=e;
			}
		}
		
		String tel=et.getTelephone();
		
		if (tel.charAt(0)=='$') {
			tel= tel.substring(1);
		}
		
		SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd");
		
		
		String res ="<form action=\"\" method=\"post\" class=\"form-style-9\">\r\n" + 
				"      <ul>\r\n" + 
				"        <li>\r\n" + 
				"          <input type=\"text\" Value ="+et.getNom()+" name=\"nom\" class=\"field-style field-split align-left\" placeholder=\"Nom\" />\r\n" + 
				"          <input type=\"text\" Value ="+et.getPrenom()+" name=\"prenom\" class=\"field-style field-split align-right\" placeholder=\"Prénom\" />\r\n" + 
				"\r\n" + 
				"\r\n" + 
				"        </li>\r\n" + 
				"        <li>\r\n" + 
				"          Date de naissance \r\n" + 
				"          <input type=\"date\" value="+s.format(et.getDateNaissance().getTime())+" name=\"dateNaissance\" class=\"field-style field-split align-right\" placeholder=\"Date de naissance\" />\r\n" + 
				"\r\n" + 
				"          \r\n" + 
				"          \r\n" + 
				"        </li>\r\n" + 
				"        <li>\r\n" + 
				"          <input type=\"text\" value="+et.getAdresse()[0]+" name=\"adr1\" class=\"field-style field-split align-left\" placeholder=\"Adresse 1\" />\r\n" + 
				"          <input type=\"text\" value="+et.getAdresse()[1]+" name=\"adr2\" class=\"field-style field-split align-right\" placeholder=\"Adresse 2\" />\r\n" + 
				"        </li>\r\n" + 
				"        <li>\r\n" + 
				"          <input type=\"text\" value="+tel+" name=\"telephone\" class=\"field-style field-split align-left\" placeholder=\"Téléphone\" />\r\n" + 
				"          <input type=\"text\" value="+et.getMail()+" name=\"email\" class=\"field-style field-split align-right\" placeholder=\"Email\" />\r\n" + 
				"        </li>\r\n" + 
				"        <li>\r\n" + 
				"          <input type=\"text\" value="+et.getBac().getType()+" name=\"typebac\" class=\"field-style field-split align-left\" placeholder=\"Type Bac\" />\r\n" + 
				"          <input type=\"text\" value="+et.getBac().getAnneeBac()+" name=\"dateBac\" class=\"field-style field-split align-right\" placeholder=\"Année d'obtention\" />\r\n" + 
				"        </li>\r\n" + 
				"        <!-- S1-->\r\n" + 
				"        \r\n" + 
				"        <li>\r\n" + 
				"          <input type=\"text\" value="+et.getSemestres()[0].getNote()+" name=\"notes1\" class=\"field-style field-split align-left\" placeholder=\"Note S1\" />\r\n" + 
				"          <input type=\"text\" value="+et.getSemestres()[0].getResultat()+" name=\"resultats1\" class=\"field-style field-split align-right\" placeholder=\"Resultat S1\" />\r\n" + 
				"        </li>\r\n" + 
				"        <li>\r\n" + 
				"          <textarea  name=\"coms1\" class=\"field-style\" placeholder=\"Commentaire S1\">"+et.getSemestres()[0].getCommentaire()+"</textarea>\r\n" + 
				"        </li>\r\n" + 
				"        <!-- S2-->\r\n" + 
				"        <li>\r\n" + 
				"          <input type=\"text\" value="+et.getSemestres()[1].getNote()+" name=\"notes2\" class=\"field-style field-split align-left\" placeholder=\"Note S2\" />\r\n" + 
				"          <input type=\"text\" value="+et.getSemestres()[1].getResultat()+" name=\"resultats2\" class=\"field-style field-split align-right\" placeholder=\"Resultat S2\" />\r\n" + 
				"        </li>\r\n" + 
				"        <li>\r\n" + 
				"          <textarea  name=\"coms2\" class=\"field-style\" placeholder=\"Commentaire S2\">"+et.getSemestres()[1].getCommentaire()+"</textarea>\r\n" + 
				"        </li>\r\n" + 
				"        <!-- S3-->\r\n" + 
				"        <li>\r\n" + 
				"          <input type=\"text\" value="+et.getSemestres()[2].getNote()+" name=\"notes3\" class=\"field-style field-split align-left\" placeholder=\"Note S3\" />\r\n" + 
				"          <input type=\"text\" value="+et.getSemestres()[2].getResultat()+" name=\"resultats3\" class=\"field-style field-split align-right\" placeholder=\"Resultat S3\" />\r\n" + 
				"        </li>\r\n" + 
				"        <li>\r\n" + 
				"          <textarea name=\"coms3\" class=\"field-style\" placeholder=\"Commentaire S3\">"+et.getSemestres()[2].getCommentaire()+"</textarea>\r\n" + 
				"        </li>\r\n" + 
				"        <!-- S4-->\r\n" + 
				"        <li>\r\n" + 
				"          <input type=\"text\" value="+et.getSemestres()[3].getNote()+" name=\"notes4\" class=\"field-style field-split align-left\" placeholder=\"Note S4\" />\r\n" + 
				"          <input type=\"text\" value="+et.getSemestres()[3].getResultat()+" name=\"resultats4\" class=\"field-style field-split align-right\" placeholder=\"Resultat S4\" />\r\n" + 
				"        </li>\r\n" + 
				"        <li>\r\n" + 
				"          <textarea name=\"coms4\" class=\"field-style\" placeholder=\"Commentaire S4\">"+et.getSemestres()[3].getCommentaire()+"</textarea>\r\n" + 
				"        </li>\r\n" + 
				"        \r\n" + 
				
				"        <li>\r\n" + 
				"          <input type=\"text\" value="+et.getNbAnneesDUT()+" name=\"dut2ou3\" class=\"field-style field-split align-left\" placeholder=\"DUT 2 ou 3 ans\" />\r\n" + 
				"          <input type=\"text\" value="+et.getPromo()+" name=\"promo\" class=\"field-style field-split align-right\" placeholder=\"Promo\" />\r\n" + 
				"        </li>\r\n" + 
				"        <li>\r\n" + 
				"          <input type=\"text\" value="+et.getPoursuite()+" name=\"poursuite\" class=\"field-style field-split align-left\" placeholder=\"Apres le DUT\" />\r\n" + 
				"        </li>\r\n" + 
				
				
				"        <li class=\"button\">\r\n" + 
				"          <input type=\"submit\" value=\"Valider\" />\r\n" + 
				"          <input type=\"submit\" value=\"Annuler\" />\r\n" + 
				"        </li>\r\n" + 
				"      </ul>\r\n" + 
				"    </form>";
		
		
		
		
		return res;
		
		
		
	}
	
	
	
	@SuppressWarnings("null")
	public static String testChamp(HttpServletRequest requete) {
		
		String nom = requete.getParameter("nom");
		String sexe = requete.getParameter("sexe");
		String prenom = requete.getParameter("prenom");
		String dateN = requete.getParameter("dateNaissance");
		String adr1 = requete.getParameter("adr1");
		String adr2 = requete.getParameter("adr2");
		String tel = requete.getParameter("telephone");
		String mail = requete.getParameter("email");
		String bac = requete.getParameter("typeBac");
		String aBac = requete.getParameter("dateBac");
		String ns1 = requete.getParameter("notes1");
		String rs1 = requete.getParameter("resultats1");
		String cs1 = requete.getParameter("coms1");
		String ns2 = requete.getParameter("notes2");
		String rs2 = requete.getParameter("resultats2");
		String cs2 = requete.getParameter("coms2");
		String ns3 = requete.getParameter("notes3");
		String rs3 = requete.getParameter("resultats3");
		String cs3 = requete.getParameter("coms3");
		String ns4 = requete.getParameter("notes4");
		String rs4 = requete.getParameter("resultats4");
		String cs4 = requete.getParameter("coms4");
		String dut = requete.getParameter("DUT2ou3");
		String promo = requete.getParameter("promo");
		String poursuite = requete.getParameter("poursuite");
		
		if(nom!=null){
		if (nom!=null &&!nom.equals("") && prenom!=null &&!prenom.equals("") && dateN!=null&&!dateN.equals("") && adr1!=null &&!adr1.equals("")&& tel!=null &&!tel.equals("") && mail!=null &&!mail.equals("") && bac!=null&&!bac.equals("")&&aBac!=null&&!aBac.equals("")&& promo!=null&&!promo.equals("")
				) {
			Semestre s1 = new Semestre(rs1, cs1,ns1);
			Semestre s2 = new Semestre(rs2, cs2,ns2);
			Semestre s3 = new Semestre(rs3, cs3,ns3);
			Semestre s4 = new Semestre(rs4, cs4,ns4);
			Semestre[] semestre={s1,s2,s3,s4};
			
			String[] adresse ={adr1,adr2};
			
			String[] date = dateN.split("-");
			Calendar c = Calendar.getInstance();
			if (date.length==3) {
				c.set(Integer.parseInt(date[0]), Integer.parseInt(date[1]) - 1, Integer.parseInt(date[2]));

			}
			
			if (dut.equals("")||dut==null) {
				dut="2";
			}
			
			Bac b = new Bac(bac,aBac);
			
			Etudiant e = new Etudiant(13, nom, prenom, sexe, c, b, mail, tel, semestre, poursuite,2, adresse, 2010);
		
			System.out.println("Etudiant "+e.toString());
			
			ArrayList<Etudiant> lse = new ArrayList<>();
			lse.add(e);
			Outils.uploadArrayEtudiants(lse);
			
			return "<p class=\"erreur\">Etudiant importé !</p>";
		}else{
			return "<p class=\"erreur\" >Champ mal rempli</p>";
		}
		}
		return "";
		
	
		/*
		System.out.println(
						nom+"\n"+
						prenom+"\n"+
						dateN+"\n"+
						adr1+"\n"+
						adr2+"\n"+
						tel+"\n"+
						mail+"\n"+
						bac+"\n"+
						ns1+"\n"+
						rs1+"\n"+
						cs1+"\n"+
						ns2+"\n"+
						rs2+"\n"+
						cs2+"\n"+
						ns3+"\n"+
						rs3+"\n"+
						cs3+"\n"+
						ns4+"\n"+
						rs4+"\n"+
						cs4+"\n"+
						dut+"\n"+
						promo+"\n"+
						poursuite+"\n"
						
				);
		
*/
	}
		
	
	
	
	

}
