import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.*;

public class Connect {

	public static void main(String[] args) {
		
		// COMMENT LES STRINGS SONT AFFICHES DE CETTE SORTE:
		// CHAQUE ATTRIBUT EST SEPARE D'UN ESPACE
		// IL Y A UN SAUT DE LIGNE A LA FIN D'UNE LIGNE
		Connection co;
		try {
			//Class driver_class = Class.forName(Parametres.JDBC_DRIVER); // BESOIN POUR JDBC ET MYSQL
			 co = DriverManager.getConnection(Parametres.url, Parametres.usr, Parametres.pwd); // CONNEXION

			System.out.println("Connect� !");
			
			// LES LIGNES SUIVANTES SONT DES TESTS ET AUSSI POUR MONTRER COMMENT FAIRE DES REQUETES
			Statement st = co.createStatement();	
			ResultSet rs = st.executeQuery("select * from equipefoot"); // 1ERE REQUETE - A CHANGER SELON LA BD
			afficherResultatRequete(rs); // Affiche la requete pr�c�dente
			ResultSet rs2 = st.executeQuery("select * from joueurfoot"); // 2EME REQUETE - A CHANGER SELON LA BD
			afficherResultatRequete(rs2);  // Affiche la 2�me requete			
		//	PreparedStatement ps = co.prepareStatement("select * from recette where categorie='?'");
		//	afficherResultatAvecSaisie(ps); // NE FONCTIONNE PAS POUR L'INSTANT
		} catch (SQLException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}
	// AFFICHE REQUETE
	public static void afficherResultatRequete(ResultSet rs) {	
		System.out.println(returnResultatRequete(rs));
	}
	
	// RETOURNE REQUETE EN STRING, VOIR DEBUT DU PROGRAMME MAIN POUR VOIR COMMENT EST CONSTITUE LE STRING
	public static String returnResultatRequete(ResultSet rs) {
		String query = "";
		try {
			ResultSetMetaData rsmd = rs.getMetaData();
			int nbColonne = rsmd.getColumnCount();
			while (rs.next()) {
				for (int i = 1; i <= nbColonne; i++) {
					query += rs.getString(i)+"]]";
				}
				query += "\n";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return query;

	}
	
	// OPTIONNEL : A CHANGER SELON LA BD + QUELQUES PETITS PROBLEMES
	public static void afficherResultatAvecSaisie(PreparedStatement ps) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Quelle Groupe ? :");
		String grpEtud = sc.nextLine();
		System.out.println(grpEtud);
		try {
			ps.setString(1, grpEtud);
			System.out.println(ps);
			ResultSet rs = ps.executeQuery();
			afficherResultatRequete(rs);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
